module.exports = ({
  name: "reloadcmds",
  aliases: [""],
  code: `
 $updateCommands
  ⚙️ • todos comandos recarregados
  `
});