module.exports = ({
 name: "help",
 aliases: ["ajuda", "comandos", "commands"],
code: `
$title[ 📋 • Lista de comandos]
$color[#1cd370]
$description[
]
$footer[utilizado por $username]
`});