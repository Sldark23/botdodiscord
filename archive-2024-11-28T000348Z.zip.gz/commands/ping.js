module.exports = ({
  name: "ping",
  aliases: ["ms","pingms"],
  code: `
  📟 • Meu ping e $pingms e cpu $cpu[process]
  `
})