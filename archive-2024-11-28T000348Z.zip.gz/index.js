const { AoiClient } = require("aoi.js");

const client = new AoiClient({
    token: "MTMwOTA4NDA5OTA4NDAyNTg2Ng.GJ0F6y.x9YZVZc8Ij9zn0q3zJ5Mif0pA_3uKPzOXnKedo", // Here goes the Token you copied earlier!
    prefix: "kx!", // Here goes the prefix you want to use for your bot!
    intents: ["MessageContent", "Guilds", "GuildMessages"],
    events: ["onMessage", "onInteractionCreate"],
    database: {
        type: "aoi.db",
        db: require("@aoijs/aoi.db"),
        dbType: "KeyValue",
        tables: ["main"],
        securityKey: "a-32-characters-long-string-here"
    }
});

// Ping Command which responds when doing "!ping"
client.loadCommands("./commands");